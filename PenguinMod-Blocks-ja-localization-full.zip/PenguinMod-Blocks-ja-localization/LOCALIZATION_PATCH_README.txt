PenguinMod-Blocks Japanese localization patch
=============================================

This bundle adds Japanese translations for 125 hardcoded English labels in production
blocks_vertical/*.js, plus the source/catalog/generation changes needed to keep them.

Included:
- msg/messages.js: source English entries for the new PM_CUSTOM_BLOCK_* keys
- msg/json/*.json: locale catalogs aligned to the complete 424-key English catalog
  (existing translations are preserved; missing new labels fall back to English except ja)
- msg/js/en.js and msg/js/ja.js: generated JS catalogs
- msg/scratch_msgs.js: regenerated combined locale catalog
- i18n/json_to_js.js: optional locale argument (defaults to en)
- package.json: translate:ja and translate:scratch scripts
- production blocks_vertical JS files: hardcoded labels changed to Blockly.Msg keys

Useful commands (from the repository root, with dependencies installed):
  npm run translate
  npm run translate:ja
  npm run translate:scratch
  npm run test:messages

Notes:
- The full npm test suite was not run in this environment because node_modules is not installed.
- New custom-block labels are translated in Japanese. For other locales, new labels use
  the English source text until translated.
- This is a generated patch bundle based on the provided ZIP, not a GitHub PR.
