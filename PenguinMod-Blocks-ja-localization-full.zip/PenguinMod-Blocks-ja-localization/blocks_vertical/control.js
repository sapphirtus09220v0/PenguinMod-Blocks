/**
 * @license
 * Visual Blocks Editor
 *
 * Copyright 2016 Massachusetts Institute of Technology
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

goog.provide('Blockly.Blocks.control');

goog.require('Blockly.Blocks');
goog.require('Blockly.Colours');
goog.require('Blockly.ScratchBlocks.VerticalExtensions');

Blockly.Blocks['control_forever'] = {
  /**
   * Block for repeat n times (external number).
   * https://blockly-demo.appspot.com/static/demos/blockfactory/index.html#5eke39
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_forever",
      "message0": Blockly.Msg.CONTROL_FOREVER,
      "message1": "%1", // Statement
      "message2": "%1", // Icon
      "lastDummyAlign2": "RIGHT",
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });

    this.nextStatementIsDynamic_ = true;
    this.setNextStatement(false);
    this.hasBreak_ = false;
  },
  mutationToDom: function() {
    var container = document.createElement('mutation');
    container.setAttribute('hasbreak', this.hasBreak_);
    return container;
  },
  domToMutation: function(xmlElement) {
    var hasNext = (xmlElement.getAttribute('hasbreak') == 'true');
    this.hasBreak_ = hasNext;
    this.setNextStatement(hasNext, "normal");
  }
};

Blockly.Blocks['control_repeat'] = {
  /**
   * Block for repeat n times (external number).
   * https://blockly-demo.appspot.com/static/demos/blockfactory/index.html#so57n9
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_repeat",
      "message0": Blockly.Msg.CONTROL_REPEAT,
      "message1": "%1", // Statement
      "message2": "%1", // Icon
      "lastDummyAlign2": "RIGHT",
      "args0": [
        {
          "type": "input_value",
          "name": "TIMES"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_repeatForSeconds'] = {
  /**
   * pm: Block to repeat for n seconds (external number).
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_repeatForSeconds",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_REPEAT_FOR_ARG1_SECONDS,
      "message1": "%1", // Statement
      "message2": "%1", // Icon
      "lastDummyAlign2": "RIGHT",
      "args0": [
        {
          "type": "input_value",
          "name": "TIMES"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_if'] = {
  /**
   * Block for if-then.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "type": "control_if",
      "message0": Blockly.Msg.CONTROL_IF,
      "message1": "%1", // Statement
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_if_else'] = {
  /**
   * Block for if-else.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "type": "control_if_else",
      "message0": Blockly.Msg.CONTROL_IF,
      "message1": "%1",
      "message2": Blockly.Msg.CONTROL_ELSE,
      "message3": "%1",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args3": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK2"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_expandableIf'] = {
  /**
   * pm: Block for expandable if else
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_HIDDEN_ARG1_ARG2,
      "args0": [
        {
          "type": "field_expandable_remove",
          "name": "REMOVE"
        },
        {
          "type": "field_expandable_add",
          "name": "ADD"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });

    this.branches_ = 0;
    this.nextIsElse = true;
    this.endsInElse = false;
    this.expandable_ = true;
  },

  fillInBlock: Blockly.scratchBlocksUtils.generateMutatorShadow,
  fixupButtons: function() {
    const expandableInput = this.getInput("");
    this.inputList.splice(this.inputList.indexOf(expandableInput), 1);
    this.inputList.push(expandableInput);

    expandableInput.setAlign(1);
    const hiddenBtn = expandableInput.fieldRow[0];
    hiddenBtn.size_.width = 0.5;
    hiddenBtn.size_.height = Blockly.BlockSvg.INPUT_SHAPE_HEIGHT + 16;
    hiddenBtn.setVisible(false);
  },
  addCase: function(shouldPopulate) {
    if (this.nextIsElse) {
      this.appendDummyInput(`TEXTSTART${this.branches_}`).appendField("else");
      this.appendStatementInput(`SUBSTACK${this.branches_}`).setCheck("normal");
      this.endsInElse = true;
    } else {
      const prevText = this.getInput(`TEXTSTART${this.branches_}`);
      if (prevText) prevText.appendField("if");
      else this.appendDummyInput(`TEXTSTART${this.branches_}`).appendField("if");
      const input = this.appendValueInput(`BOOL${this.branches_}`).setCheck("Boolean");
      if (!this.isInsertionMarker_) {
        input.init();
        input.initOutlinePath(this.svgGroup_);
        input.outlinePath.setAttribute('fill', this.getColourTertiary());
      }
      if (shouldPopulate) this.fillInBlock(input.connection, "checkbox");
      this.appendDummyInput(`TEXTEND${this.branches_}`).appendField("then");

      // swap out the connection with the old and new branch
      const prevBranch = this.getInput(`SUBSTACK${this.branches_}`);
      const newBranch = this.appendStatementInput(`SUBSTACK${this.branches_}`).setCheck("normal");
      if (this.branches_ > 1) {
        const prevBranchBlock = prevBranch.connection.targetBlock();
        if (prevBranchBlock) newBranch.connection.connect(prevBranchBlock.previousConnection);
        this.removeInput(`SUBSTACK${this.branches_}`);
      }
      this.endsInElse = false;
    }

    this.fixupButtons();
  },

  mutationToDom: function() {
    // on save
    const container = document.createElement("mutation");
    container.setAttribute("branches", String(this.branches_));
    container.setAttribute("ends-in-else", String(this.endsInElse));
    return container;
  },

  domToMutation: function(xmlElement) {
    // on load
    const inputCount = Number(xmlElement.getAttribute("branches"));
    let branchCount = isNaN(inputCount) ? 0 : inputCount;
    let needsActionConnect = false, oldConnections;

    if (this.inputList.length - 1 > 0) {
      // this was a control z action
      needsActionConnect = true;
      oldConnections = this.getConnections_().map(c => c.targetBlock());

      // clear block
      for (var i = this.inputList.length - 1; i--;) {
        const input = this.inputList[i];
        if (input.name.startsWith("SUBSTACK") || input.name.startsWith("BOOL")) {
          if (input.connection.targetBlock()) input.connection.disconnect();
        }
        this.removeInput(input.name);
      }
    }

    if (branchCount > 1) {
      branchCount = (branchCount * 2) - 1;
      if (xmlElement.getAttribute("ends-in-else") === "true") branchCount -= 1;
    }

    this.nextIsElse = false;
    this.endsInElse = false;
    this.branches_ = 1;
    for (let i = 0; i < branchCount; i++) {
      if (this.nextIsElse) this.branches_++;
      // vm handles shadow values
      this.addCase(false);
      this.nextIsElse = !this.nextIsElse;
    }

    this.fixupButtons();
    if (needsActionConnect) {
      let index = 2;
      for (var i = 0; i < this.inputList.length; i++) {
        const input = this.inputList[i];
        if (input.name.startsWith("SUBSTACK") || input.name.startsWith("BOOL")) {
          const oldBlock = oldConnections[index];
          if (oldBlock) {
            try {
              const connector = oldBlock.outputConnection ? oldBlock.outputConnection : oldBlock.previousConnection;
              input.connection.connect(connector);
            } catch(e) {}
          }
          index++;
        }
      }
      for (var i = index - 1; i < oldConnections.length; i++) {
        if (oldConnections[i] && oldConnections[i].type === "checkbox") oldConnections[i].dispose();
      }
    }
  },

  onExpandableButtonClicked_: function (isAdding) {
    // Create an event group to keep field value and mutator in sync
    // Return null at the end because setValue is called here already.
    if (this.isInFlyout) return;
    Blockly.Events.setGroup(true);
    Blockly.Events.expandableClick = true;
    var oldMutation = Blockly.Xml.domToText(this.mutationToDom());
    if (isAdding) {
      if (this.nextIsElse) this.branches_++;
      this.addCase(true);
      this.nextIsElse = !this.nextIsElse;
    } else if (this.branches_ > 1) {
      const boolInput = this.getInput(`BOOL${this.branches_}`);
      if (boolInput) {
        const block = boolInput.connection.targetBlock();
        if (block) {
          if (block.type === "checkbox") block.dispose();
          else block.outputConnection.disconnect();
        }
      }

      this.removeInput(`BOOL${this.branches_}`);
      this.removeInput(`SUBSTACK${this.branches_}`);
      this.removeInput(`TEXTSTART${this.branches_}`);
      this.removeInput(`TEXTEND${this.branches_}`);
      this.branches_--;
      this.nextIsElse = true;
      this.endsInElse = false;
    }

    this.initSvg();
    if (this.rendered) this.render();

    var newMutation = Blockly.Xml.domToText(this.mutationToDom());
    Blockly.Events.fire(new Blockly.Events.BlockChange(
      this, 'mutation', null, oldMutation, newMutation
    ));
    Blockly.Events.setGroup(false);
    Blockly.Events.expandableClick = false;
  }
};

Blockly.Blocks['control_try_catch'] = {
  /**
   * Block for try-catch.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "type": "control_try_catch",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_TRY_TO_DO,
      "message1": "%1",
      "message2": Blockly.Msg.PM_CUSTOM_BLOCK_IF_A_BLOCK_ERRORS,
      "message3": "%1",
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args3": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK2"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_throw_error'] = {
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_THROW_ERROR_ARG1,
      "args0": [
        {
          "type": "input_value",
          "name": "ERROR"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_end"]
    });
  }
};

Blockly.Blocks['control_error'] = {
  /**
   * pm: Block to get a try catch error.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_ERROR,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "output_string"]
    });
  }
};

Blockly.Blocks['control_stop'] = {
  /**
   * Block for stop all scripts.
   * @this Blockly.Block
   */
  init: function() {
    var ALL_SCRIPTS = 'all';
    var THIS_SCRIPT = 'this script';
    var OTHER_SCRIPTS = 'other scripts in sprite';
    var stopDropdown = new Blockly.FieldDropdown(function() {
      if (this.sourceBlock_ &&
          this.sourceBlock_.nextConnection &&
          this.sourceBlock_.nextConnection.isConnected()) {
        return [
          [Blockly.Msg.CONTROL_STOP_OTHER, OTHER_SCRIPTS]
        ];
      }
      return [[Blockly.Msg.CONTROL_STOP_ALL, ALL_SCRIPTS],
        [Blockly.Msg.CONTROL_STOP_THIS, THIS_SCRIPT],
        [Blockly.Msg.CONTROL_STOP_OTHER, OTHER_SCRIPTS]
      ];
    }, function(option) {
      // Create an event group to keep field value and mutator in sync
      // Return null at the end because setValue is called here already.
      Blockly.Events.setGroup(true);
      var oldMutation = Blockly.Xml.domToText(this.sourceBlock_.mutationToDom());
      this.sourceBlock_.setNextStatement(option == OTHER_SCRIPTS, "normal");
      var newMutation = Blockly.Xml.domToText(this.sourceBlock_.mutationToDom());
      Blockly.Events.fire(new Blockly.Events.BlockChange(this.sourceBlock_,
          'mutation', null, oldMutation, newMutation));
      this.setValue(option);
      Blockly.Events.setGroup(false);
      return null;
    });
    this.appendDummyInput()
        .appendField(Blockly.Msg.CONTROL_STOP)
        .appendField(stopDropdown, 'STOP_OPTION');
    this.setCategory(Blockly.Categories.control);
    this.setColour(Blockly.Colours.control.primary,
        Blockly.Colours.control.secondary,
        Blockly.Colours.control.tertiary
    );
    this.setPreviousStatement(true, "normal");
  },
  mutationToDom: function() {
    var container = document.createElement('mutation');
    container.setAttribute('hasnext', this.nextConnection != null);
    return container;
  },
  domToMutation: function(xmlElement) {
    var hasNext = (xmlElement.getAttribute('hasnext') == 'true');
    this.setNextStatement(hasNext, "normal");
  }
};

Blockly.Blocks['control_wait'] = {
  /**
   * Block to wait (pause) stack.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_wait",
      "message0": Blockly.Msg.CONTROL_WAIT,
      "args0": [
        {
          "type": "input_value",
          "name": "DURATION"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_waitsecondsoruntil'] = {
  /**
   * pm: Block to wait (pause) stack for a specified amount of seconds, or until a condition is met.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_waitsecondsoruntil",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_WAIT_ARG1_SECONDS_OR_UNTIL_ARG2,
      "args0": [
        {
          "type": "input_value",
          "name": "DURATION"
        },
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_waittick'] = {
  /**
   * pm: Block to wait (pause) stack until the next runtime tick.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_waittick",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_WAIT_UNTIL_NEXT_TICK,
      "args0": [],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_wait_until'] = {
  /**
   * Block to wait until a condition becomes true.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_WAITUNTIL,
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_repeat_until'] = {
  /**
   * Block to repeat until a condition becomes true.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_REPEATUNTIL,
      "message1": "%1",
      "message2": "%1",
      "lastDummyAlign2": "RIGHT",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_while'] = {
  /**
   * pm: Block to repeat until a condition becomes false.
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_WHILE,
      "message1": "%1",
      "message2": "%1",
      "lastDummyAlign2": "RIGHT",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION",
          "check": "Boolean"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_for_each'] = {
  /**
   * pm: Block for for-each loops.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "type": "control_for_each",
      "message0": Blockly.Msg.CONTROL_FOREACH,
      "message1": "%1",
      "message2": "%1",
      "lastDummyAlign2": "RIGHT",
      "args0": [
        {
          "type": "field_variable",
          "name": "VARIABLE"
        },
        {
          "type": "input_value",
          "name": "VALUE"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "args2": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_start_as_clone'] = {
  /**
   * Block for "when I start as a clone" hat.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_start_as_clone",
      "message0": Blockly.Msg.CONTROL_STARTASCLONE,
      "args0": [
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_hat"]
    });
  }
};

Blockly.Blocks['control_create_clone_of_menu'] = {
  /**
   * Create-clone drop-down menu.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": "%1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "CLONE_OPTION",
          "options": [
            [Blockly.Msg.CONTROL_CREATECLONEOF_MYSELF, '_myself_']
          ]
        }
      ],
      "extensions": ["colours_control", "output_string"]
    });
  }
};

Blockly.Blocks['control_create_clone_of'] = {
  /**
   * Block for "create clone of..."
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_start_as_clone",
      "message0": Blockly.Msg.CONTROL_CREATECLONEOF,
      "args0": [
        {
          "type": "input_value",
          "name": "CLONE_OPTION"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_delete_clones_of'] = {
  /**
   * pm: Block for "delete clones of..."
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_delete_clones_of",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_DELETE_CLONES_OF_ARG1,
      "args0": [
        {
          "type": "input_value",
          "name": "CLONE_OPTION"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_delete_this_clone'] = {
  /**
   * Block for "delete this clone."
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_DELETETHISCLONE,
      "args0": [
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_end"]
    });
  }
};

Blockly.Blocks['control_is_clone'] = {
  /**
   * pm: Block to check if a sprite is a clone.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_IS_CLONE,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "output_boolean"]
    });
  }
};

Blockly.Blocks['control_stop_sprite_menu'] = {
  /**
   * pm: Stop-sprite drop-down menu.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": "%1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "STOP_OPTION",
          "options": [
            ["stage", '_stage_']
          ]
        }
      ],
      "extensions": ["colours_control", "output_string"]
    });
  }
};

Blockly.Blocks['control_stop_sprite'] = {
  /**
   * pm: Block for "stop (...)"
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "id": "control_stop_sprite",
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_STOP_ARG1,
      "args0": [
        {
          "type": "input_value",
          "name": "STOP_OPTION"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_run_as_sprite_menu'] = {
  /**
   * pm: Run-as-sprite drop-down menu.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": "%1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "RUN_AS_OPTION",
          "options": [
            ["Stage", '_stage_']
          ]
        }
      ],
      "extensions": ["colours_control", "output_string"]
    });
  }
};

Blockly.Blocks['control_run_as_sprite'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_AS_ARG1_DO,
      "message1": "%1",
      "args0": [
        {
          "type": "input_value",
          "name": "RUN_AS_OPTION"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_inline_stack_output'] = {
  /**
   * pm: Block to run a stack and output a return from it.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_INLINE_BLOCK,
      "message1": "%1",
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "output": null,
      "outputShape": Blockly.OUTPUT_SHAPE_SQUARE,
      "extensions": ["colours_control"]
    });
  }
};

Blockly.Blocks['control_get_counter'] = {
  /**
   * pm: Block to get the counter value.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_COUNTER,
      "category": Blockly.Categories.control,
      "checkboxInFlyout": true,
      "extensions": ["colours_control", "output_number"]
    });
  }
};

Blockly.Blocks['control_incr_counter'] = {
  /**
   * pm: Block to add one to the counter value.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_INCRCOUNTER,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_decr_counter'] = {
  /**
   * pm: Block to subtract one from the counter value.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_DECREMENT_COUNTER,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_set_counter'] = {
  /**
   * pm: Block to set the counter value.
   * @this Blockly.Block
   */
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_SET_COUNTER_TO_ARG1,
      "args0": [
        {
          "type": "input_value",
          "name": "VALUE"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_clear_counter'] = {
  /**
   * pm: Block to clear the counter value.
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_CLEARCOUNTER,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_all_at_once'] = {
  /**
   * Block to run the contained script. This is an obsolete block that is
   * implemented for compatibility with Scratch 2.0 projects. Note that
   * this was originally designed to run all of the contained blocks
   * (sequentially, like normal) within a single frame, but this feature
   * was removed in place of custom blocks marked "run without screen
   * refresh". The "all at once" block was changed to run the contained
   * blocks ordinarily, functioning the same way as an "if" block with a
   * reporter that is always true (e.g. "if 1 = 1"). Also note that the
   * Scratch 2.0 spec for this block is "warpSpeed", but the label shows
   * "all at once".
   * @this Blockly.Block
   */
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.CONTROL_ALLATONCE,
      "message1": "%1", // Statement
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_new_script'] = {
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_NEW_SCRIPT,
      "message1": "%1", // Statement
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks["control_backToGreenFlag"] = {
  init: function() {
    this.jsonInit({
      "inputsInline": true,
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_RUN_ARG1,
      "args0": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "blue-flag.svg",
          "width": 24,
          "height": 24,
          "alt": "flag",
          "flip_rtl": false
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks["control_if_return_else_return"] = {
  init: function() {
    this.jsonInit({
      "inputsInline": true,
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_IF_ARG1_THEN_ARG2_ELSE_ARG3,
      "args0": [
        {
          "type": "input_value",
          "name": "boolean",
          "check": "Boolean"
        },
        {
          "type": "input_value",
          "name": "TEXT1"
        },
        {
          "type": "input_value",
          "name": "TEXT2"
        }
      ],
      "output": null,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control"],
      "outputShape": Blockly.OUTPUT_SHAPE_ROUND
    });
  }
};

Blockly.Blocks['control_switch'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_SWITCH_ARG1,
      "message1": "%1",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "name": "SUBSTACK",
          "check": 'switchCase'
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_switch_default'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_SWITCH_ARG1,
      "message1": "%1",
      "message2": Blockly.Msg.PM_CUSTOM_BLOCK_DEFAULT,
      "message3": "%1",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "name": "SUBSTACK1",
          "check": 'switchCase'
        }
      ],
      "args3": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK2"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_case'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_CASE_ARG1,
      "message1": "%1",
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION"
        }
      ],
      "args1": [
        {
          "type": "input_statement",
          "check": 'normal',
          "name": "SUBSTACK"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_case"]
    });
  }
};

Blockly.Blocks['control_case_next'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_RUN_NEXT_CASE_WHEN_ARG1,
      "args0": [
        {
          "type": "input_value",
          "name": "CONDITION"
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_case"]
    });
  }
};

Blockly.Blocks['control_exitCase'] = {
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_EXIT_CASE_ARG1,
      "args0": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "arrow-down.svg",
          "width": 24,
          "height": 24,
          "alt": "↓",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_end"]
    });
  }
};

Blockly.Blocks['control_exitLoop'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_ESCAPE_LOOP_ARG1,
      "args0": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "arrow-down.svg",
          "width": 24,
          "height": 24,
          "alt": "↓",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_end"]
    });

    this.oldLoopBlock = null;

    // its rather expensive to start listening to Blockly Events, its better
    // to patch these functions for this specific block
    this.originalSetDraggingFunc = this.setDragging;
    this.setDragging = function(adding) {
      this.originalSetDraggingFunc.call(this, adding);

      if (adding) {
        if (!this.getParent() && this.oldLoopBlock) {
          this.setForeverNub(this.oldLoopBlock, false, true);
        }
      } else {
        queueMicrotask(() => this.climbBlockTree((block) => {
          this.setForeverNub(block, true, true);
        }));
      }
    }

    this.originalSetParent = this.setParent;
    this.setParent = function(...args) {
      this.originalSetParent.call(this, ...args);
      if (this.isInsertionMarker_) return;

      queueMicrotask(() => {
        if (args[0]) this.climbBlockTree((block) => this.setForeverNub(block, true, true));
        else {
          if (!this.oldLoopBlock || this.workspace === null) return;
          this.setForeverNub(this.oldLoopBlock, false, false);
        }
      });
    }
  },
  climbBlockTree: function(callback) {
    // recursively climb tree until we reach a forever loop block
    let parent = this.getParent();
    while (parent !== null) {
      if (parent.nextStatementIsDynamic_) {
        // a smart way to check if we are a child is by checking our position
        // child blocks are not aligned on the x axis
        var childPos = this.getRelativeToSurfaceXY();
        var parentPos = parent.getRelativeToSurfaceXY();
        if (Math.round(childPos.x) !== Math.round(parentPos.x)) {
          callback(parent);
          return;
        }
      }

      parent = parent.getParent();
    }
  },
  setForeverNub: function(block, adding, callMutation) {
    var oldMutation = Blockly.Xml.domToText(block.mutationToDom());
    if (adding) {
      block.setNextStatement(true, "normal");
      block.hasBreak_ = true;
      this.oldLoopBlock = block;
      this.updateForeverMutation(oldMutation, this.oldLoopBlock);
    } else {
      this.oldLoopBlock.setNextStatement(false);
      this.oldLoopBlock.hasBreak_ = false;
      if (callMutation) this.updateForeverMutation(oldMutation, this.oldLoopBlock);
      this.oldLoopBlock = null;
    }
  },
  updateForeverMutation: function(oldMutation, foreverBlock) {
    var newMutation = Blockly.Xml.domToText(foreverBlock.mutationToDom());
    Blockly.Events.fire(new Blockly.Events.BlockChange(
      foreverBlock, 'mutation', null, oldMutation, newMutation
    ));
  }
};

Blockly.Blocks['control_continueLoop'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_CONTINUE_LOOP_ARG1,
      "args0": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "⤴",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_end"]
    });
  }
};

Blockly.Blocks['control_from_to'] = {
  init: function() {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_FOR_ARG1_OF_ARG2_TO_ARG3_ARG4,
      "message1": "%1",
      "lastDummyAlign1": "RIGHT",
      "args0": [
        {
          "type": "input_value",
          "name": "SHADOW"
        },
        {
          "type": "input_value",
          "name": "FROM"
        },
        {
          "type": "input_value",
          "name": "TO"
        },
        {
          "type": "input_statement",
          "name": "SUBSTACK"
        }
      ],
      "args1": [
        {
          "type": "field_image",
          "src": Blockly.mainWorkspace.options.pathToMedia + "repeat.svg",
          "width": 24,
          "height": 24,
          "alt": "*",
          "flip_rtl": true
        }
      ],
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "shape_statement"]
    });
  }
};

Blockly.Blocks['control_from_to_index'] = {
  init: function () {
    this.jsonInit({
      "message0": Blockly.Msg.PM_CUSTOM_BLOCK_INDEX,
      "canDragDuplicate": true,
      "category": Blockly.Categories.control,
      "extensions": ["colours_control", "output_number"]
    });
  }
};